
## File Presentation Preference

- When the user asks you to "give me a file" or "show me a file" to view, create it as a **user-facing artifact** (`UserFacing: true` in the artifact directory) so it opens directly in the right-side pane.
