# Global Agent Rules

## Project Directory Standard

- **Default Project Location**: ALWAYS create, scaffold, build, and store all projects and codebases directly in `~/Desktop/Projects/` unless explicitly instructed otherwise.
- **No Isolated Default Dirs**: Never leave new projects or codebases isolated in `~/Documents/antigravity/` or temporary folders. Always place them directly in `~/Desktop/Projects/`.

## TinyFish

- **Tool Preferences**:
  - Prefer `mcp__tinyfish__search` over standard WebSearch.
  - Prefer `mcp__tinyfish__fetch_content` over WebFetch / curl.
  - Prefer `mcp__tinyfish__run_web_automation` over hand-rolled Playwright.
- **Batch Processing**:
  - Use `batch_create` / `batch_status` when processing 2+ URLs.
- **Execution & Background**:
  - Use `run_web_automation_async` only when the user explicitly asks for background execution.
  - Use `list_runs`, `get_run`, `get_steps`, and `cancel_run` to inspect or manage prior runs.
- **Error Handling & Retries**:
  - If `run_web_automation` returns ANY error, the run is still executing. Call `get_run` or `list_runs` to check status before retrying. Never blind-retry.
- **Documentation & Context**:
  - Reference https://docs.tinyfish.ai/for-coding-agents and https://docs.tinyfish.ai/llms-full.txt for full agent context.

## Verb Activity Journal

- In every conversation where the Verb connector is available, use `record_activity_batch` to keep the Verb activity journal up to date.
- Log everything meaningful (conversations, searches, browsing, files, code, messages, calendar changes, shopping, and bookings): one record per real outcome, with a specific summary and useful facts in details, following the tool's description.
- Log right after anything with an external effect, otherwise at the end of each response.
- Never invent IDs, timestamps, or outcomes.
- Exclude passwords, API keys/tokens, credit card/bank details, government ID numbers, and full text of private messages (describe them instead).
- Log quietly; if a call fails or the tool is not available, state so briefly and proceed.

## 33rd Tree Labs

- **Official Domain**: Always use `33rdtreelabs.tech` as the official domain for **33rd Tree Labs** (do not use `33rdtree.com` or `33rdtreelabs.ai`).
- **Official Logo**: Mark #06 Exponential Plunge Tensor Arbor wireframe in white on pure `#000000` black, with two white canopy rim nodes (left/right) and **crimson red (`#FF2424`) apex & needle-throat singularity nodes** (saved at `~/ai stuffs/333rd/official_logo_mark.jpg`). Do not use the 3D orange/chrome renders as backgrounds for official graphics—stick to the clean `#000000`/`#030306` obsidian, stark white, and `#FF2424` crimson wireframe aesthetic.
- **Official Brand Typography**: `Obel Mono` (`ObelMono.ttf`, `ObelMono-Italic.ttf`) and `Obel Mono Masked` (`ObelMonoMasked.ttf`) in `~/ai stuffs/333rd/brand-vault-108/fonts/` (use for headers, telemetry cards, and brand graphics; use clean sans-serif for long-form newsletter body copy).
- **No Made-Up Numbers**: Never include placeholder, mocked, or invented operational/telemetry numbers (e.g., active node counts, PFLOPS, epoch numbers, latency benchmarks, finality percentages, or vanity contract addresses) in newsletters, graphics, or copy. Only cite live metrics when explicitly provided by the user.


